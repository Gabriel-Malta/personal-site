<?php

namespace Yoast\WP\SEO\Conditionals;

/**
 * Conditional for the Wincher integration.
 */
class Wincher_Conditional extends Non_Multisite_Conditional {}
